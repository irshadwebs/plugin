<?php
/**
* Plugin Name: Best CPT Plugin
* Plugin URI: https://www.linkedin.com/in/irshad-ahmad-24538a69/
* Description: Custom Post Type provides an easy to use interface for registering and managing custom post types for your website. Shortcode: <code>[news-listing]</code>
* Version: 1.0
* Author: Irshad Ahmad
* Author URI: https://www.linkedin.com/in/irshad-ahmad-24538a69/
**/

function add_my_css_and_my_js_files(){
	wp_enqueue_style( 'style-name', plugins_url('/css/style.css', __FILE__), false, '1.0.0', 'all');
}
add_action('wp_enqueue_scripts', "add_my_css_and_my_js_files");

/*
* Creating a function to create our CPT
*/
 
function custom_news_post_type() {
 
// Set UI labels for Custom Post Type
    $labels = array(
        'name'                => _x( 'News', 'Post Type General Name', 'lucidtheme' ),
        'singular_name'       => _x( 'News', 'Post Type Singular Name', 'lucidtheme' ),
        'menu_name'           => __( 'News', 'lucidtheme' ),
        'parent_item_colon'   => __( 'Parent News', 'lucidtheme' ),
        'all_items'           => __( 'All News', 'lucidtheme' ),
        'view_item'           => __( 'View News', 'lucidtheme' ),
        'add_new_item'        => __( 'Add New News', 'lucidtheme' ),
        'add_new'             => __( 'Add New', 'lucidtheme' ),
        'edit_item'           => __( 'Edit News', 'lucidtheme' ),
        'update_item'         => __( 'Update News', 'lucidtheme' ),
        'search_items'        => __( 'Search News', 'lucidtheme' ),
        'not_found'           => __( 'Not Found', 'lucidtheme' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'lucidtheme' ),
    );
     
// Set other options for Custom Post Type
     
    $args = array(
        'label'               => __( 'news', 'lucidtheme' ),
        'description'         => __( 'news news and reviews', 'lucidtheme' ),
        'labels'              => $labels,
        // Features this CPT supports in Post Editor
        'supports'            => array( 'title', 'editor', 'thumbnail' ),
        // You can associate this CPT with a taxonomy or custom taxonomy. 
        /* A hierarchical CPT is like Pages and can have
        * Parent and child items. A non-hierarchical CPT
        * is like Posts.
        */ 
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'post',
        'show_in_rest' => true,
 
    );
     
    // Registering your Custom Post Type
    register_post_type( 'cpt_news', $args );
 
}
 
/* Hook into the 'init' action so that the function
* Containing our post type registration is not 
* unnecessarily executed. 
*/ 
add_action( 'init', 'custom_news_post_type', 0 );


// >> Create Shortcode to Display Products Post Types  
function custom_create_shortcode_news_post_type(){
  
    $args = array(
                    'post_type'      => 'cpt_news',
                    'posts_per_page' => '10',
                    'publish_status' => 'published',
                 );
  
    $query = new WP_Query($args);
    echo '<section class="recentNews">
	<div class="container">
	  <h2 class="news-title">Recent News</h2><div class="row">';
  if($query->have_posts()) :
    	while($query->have_posts()) : $query->the_post(); ?>
		
    
      <div class="ct-blog col-sm-6 col-md-4">
        <div class="inner">
          <div class="fauxcrop">
            <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
          </div>
          <div class="ct-blog-content">
            <div class="ct-blog-date">
              <span><?php echo the_time('F'); ?> </span><?php echo the_time('d'); ?>
            </div>
            <h3 class="ct-blog-header"><?php the_title(); ?></h3>
          </div>
        </div>
      </div>
	 
	 <?php 
    	endwhile;
    	echo '</div></div></section>';
  
        wp_reset_postdata();
  
    endif;    
  
    return $result;            
}
  
add_shortcode( 'news-listing', 'custom_create_shortcode_news_post_type' ); 
// shortcode code ends here